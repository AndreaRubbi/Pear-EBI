import os
import stat
import warnings


def ensure_native_executables():
    """Ensure packaged native helper files are executable on Unix-like systems.

    This is safe to call at import time: it silently no-ops on non-POSIX
    platforms and ignores missing files.
    """
    # Only attempt on POSIX filesystems where exec bits are relevant
    if os.name != "posix":
        return

    pkg_root = os.path.dirname(__file__)
    calc_dir = os.path.join(pkg_root, "calculate_distances")

    candidates = []

    # HashRF main binary (common location)
    candidates.append(os.path.join(calc_dir, "HashRF", "hashrf"))

    # tqDist binaries under tqDist/bin/
    tq_bin_dir = os.path.join(calc_dir, "tqDist", "bin")
    if os.path.isdir(tq_bin_dir):
        for name in os.listdir(tq_bin_dir):
            candidates.append(os.path.join(tq_bin_dir, name))

    # Also ensure any scripts directly under calculate_distances are executable
    # (be conservative and only add regular files)
    if os.path.isdir(calc_dir):
        for name in ("hashrf", "tqdist", "tqDist"):
            path = os.path.join(calc_dir, name)
            if os.path.isfile(path):
                candidates.append(path)

    made_executable = []
    for path in candidates:
        try:
            if not os.path.exists(path):
                continue
            st = os.stat(path)
            # if any of the exec bits already set, skip
            if st.st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH):
                continue
            # set user/group/other execute bits
            new_mode = st.st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
            os.chmod(path, new_mode)
            made_executable.append(path)
        except Exception:
            # Be tolerant: do not fail import/install if chmod fails.
            # Log a non-fatal warning so packagers/users can notice if needed.
            warnings.warn(f"Could not mark native helper executable: {path}")

    return made_executable
